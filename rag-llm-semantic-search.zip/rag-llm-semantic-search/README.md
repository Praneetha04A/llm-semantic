# Retrieval-Augmented Generation (RAG) AI System Using LLMs and Semantic Vector Search

A Retrieval-Augmented Generation system: document ingestion, chunking, transformer-based
semantic embeddings, a FAISS vector index, similarity-based retrieval, and grounded
response generation via an LLM — with prompt engineering that forces the model to answer
only from retrieved context.

Run it:
```bash
pip install -r requirements.txt
python src/ingest.py && python src/app.py --query "How do I request access?"
```

## Architecture

```
Documents --> chunk --> embed (sentence-transformers) --> FAISS index
                                                              │
User query --> embed query --> similarity search ────────────┘
                                       │
                              top-k relevant chunks
                                       │
                       context-aware prompt --> LLM --> grounded answer
```

## Project structure

```
rag-llm-semantic-search/
├── data/
│   └── sample_docs/          # drop .txt/.md source docs here
├── src/
│   ├── ingest.py             # loads + chunks documents
│   ├── embeddings.py         # sentence-transformer embedding generation
│   ├── vector_store.py       # FAISS index build/save/load/search
│   ├── rag_pipeline.py       # retrieval + prompt construction + LLM call
│   └── app.py                # CLI + optional Flask API
├── index/                    # persisted FAISS index (generated)
├── requirements.txt
└── README.md
```

## Quickstart

```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt

# 1. Put your source documents in data/sample_docs/ (a couple samples are included)

# 2. Build the vector index
python src/ingest.py

# 3. Ask a question (retrieves context + calls the LLM)
export ANTHROPIC_API_KEY=your_key_here   # or OPENAI_API_KEY, see rag_pipeline.py
python src/app.py --query "What does the onboarding doc say about access requests?"

# Or run the small Flask API
python src/app.py --serve
# then: curl -X POST localhost:5000/ask -H "Content-Type: application/json" -d '{"query":"..."}'
```

## Design notes

- **Chunking**: recursive character splitting with overlap, to keep semantic units intact.
- **Embeddings**: `sentence-transformers/all-MiniLM-L6-v2` (local, no API cost) by default;
  swappable for an API-based embedding model.
- **Vector search**: FAISS `IndexFlatIP` (cosine similarity via normalized vectors) — swap
  for `IndexIVFFlat` or a managed vector DB (Pinecone/Weaviate/pgvector) at scale.
- **Generation**: the retrieved chunks are injected into a strict prompt template that
  instructs the model to answer only from context and say when it doesn't know — this is
  the "grounded response generation" step that reduces hallucination.
- **No API key?** `rag_pipeline.py` includes a `--no-llm` mode that just returns the raw
  retrieved chunks, so the retrieval half of the pipeline is fully demoable offline.

## License

MIT
