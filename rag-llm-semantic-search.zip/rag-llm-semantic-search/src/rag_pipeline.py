"""Retrieval + context-aware prompt construction + grounded LLM generation."""
import os
from pathlib import Path
from typing import List, Dict

from embeddings import Embedder
from vector_store import VectorStore

INDEX_DIR = Path(__file__).resolve().parent.parent / "index"

PROMPT_TEMPLATE = """You are a helpful assistant answering questions using ONLY the
context provided below. If the answer is not contained in the context, say
"I don't have enough information to answer that" rather than guessing.

Context:
{context}

Question: {question}

Answer (cite the source file for each fact you use):"""


class RAGPipeline:
    def __init__(self, index_dir: Path = INDEX_DIR, top_k: int = 4):
        self.embedder = Embedder()
        self.store = VectorStore.load(index_dir)
        self.top_k = top_k

    def retrieve(self, query: str) -> List[Dict]:
        query_vec = self.embedder.embed_query(query)
        results = self.store.search(query_vec, k=self.top_k)
        return [
            {"text": text, "source": meta["source"], "score": score}
            for text, meta, score in results
        ]

    def build_prompt(self, query: str, retrieved: List[Dict]) -> str:
        context = "\n\n".join(f"[{r['source']}]\n{r['text']}" for r in retrieved)
        return PROMPT_TEMPLATE.format(context=context, question=query)

    def generate(self, query: str) -> Dict:
        retrieved = self.retrieve(query)
        prompt = self.build_prompt(query, retrieved)

        answer = self._call_llm(prompt)
        return {"query": query, "answer": answer, "sources": retrieved}

    def _call_llm(self, prompt: str) -> str:
        api_key = os.environ.get("ANTHROPIC_API_KEY")
        if not api_key:
            return "[No ANTHROPIC_API_KEY set -- returning retrieved context only. " \
                   "Set the env var to enable grounded generation.]"

        import anthropic
        client = anthropic.Anthropic(api_key=api_key)
        response = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=500,
            messages=[{"role": "user", "content": prompt}],
        )
        return "".join(block.text for block in response.content if block.type == "text")
