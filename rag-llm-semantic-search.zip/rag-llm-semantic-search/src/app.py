"""CLI + optional Flask API for querying the RAG pipeline.

Usage:
    python src/app.py --query "How do I request access?"
    python src/app.py --no-llm --query "..."   # retrieval only, no LLM call
    python src/app.py --serve                  # runs a Flask API on :5000
"""
import argparse
from rag_pipeline import RAGPipeline


def run_query(query: str, no_llm: bool = False):
    pipeline = RAGPipeline()
    if no_llm:
        results = pipeline.retrieve(query)
        print(f"\nTop {len(results)} retrieved chunks for: {query!r}\n")
        for r in results:
            print(f"[{r['source']}] (score={r['score']:.3f})\n{r['text']}\n")
        return

    result = pipeline.generate(query)
    print(f"\nQuestion: {result['query']}\n")
    print(f"Answer:\n{result['answer']}\n")
    print("Sources used:")
    for s in result["sources"]:
        print(f"  - {s['source']} (score={s['score']:.3f})")


def serve():
    from flask import Flask, request, jsonify
    app = Flask(__name__)
    pipeline = RAGPipeline()

    @app.route("/ask", methods=["POST"])
    def ask():
        query = request.json.get("query", "")
        if not query:
            return jsonify({"error": "missing 'query'"}), 400
        return jsonify(pipeline.generate(query))

    app.run(host="0.0.0.0", port=5000)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--query", type=str, help="Question to ask the RAG system")
    parser.add_argument("--no-llm", action="store_true", help="Retrieval only, skip the LLM call")
    parser.add_argument("--serve", action="store_true", help="Run as a Flask API instead")
    args = parser.parse_args()

    if args.serve:
        serve()
    elif args.query:
        run_query(args.query, no_llm=args.no_llm)
    else:
        parser.print_help()
