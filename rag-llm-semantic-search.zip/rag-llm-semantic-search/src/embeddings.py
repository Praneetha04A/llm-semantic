"""Thin wrapper around a sentence-transformers model for embedding generation."""
from typing import List
import numpy as np
from sentence_transformers import SentenceTransformer

DEFAULT_MODEL = "all-MiniLM-L6-v2"


class Embedder:
    def __init__(self, model_name: str = DEFAULT_MODEL):
        self.model = SentenceTransformer(model_name)

    def embed(self, texts: List[str]) -> np.ndarray:
        texts = list(texts)
        vectors = self.model.encode(texts, convert_to_numpy=True, show_progress_bar=False)
        # normalize so inner product == cosine similarity
        norms = np.linalg.norm(vectors, axis=1, keepdims=True)
        norms[norms == 0] = 1e-8
        return vectors / norms

    def embed_query(self, text: str) -> np.ndarray:
        return self.embed([text])[0]
