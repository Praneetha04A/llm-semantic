"""Loads documents, chunks them, embeds the chunks, and builds/saves a FAISS index.

Usage:
    python src/ingest.py
"""
from pathlib import Path
from typing import List, Dict
from tqdm import tqdm

from embeddings import Embedder
from vector_store import VectorStore

DOCS_DIR = Path(__file__).resolve().parent.parent / "data" / "sample_docs"
INDEX_DIR = Path(__file__).resolve().parent.parent / "index"

CHUNK_SIZE = 500       # characters per chunk
CHUNK_OVERLAP = 80     # character overlap between consecutive chunks


def load_documents(docs_dir: Path = DOCS_DIR) -> List[Dict]:
    docs = []
    for path in sorted(docs_dir.glob("*.*")):
        if path.suffix.lower() not in (".txt", ".md"):
            continue
        text = path.read_text(encoding="utf-8")
        docs.append({"source": path.name, "text": text})
    return docs


def chunk_text(text: str, chunk_size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP) -> List[str]:
    """Recursive-ish character splitter: tries to break on paragraph/sentence
    boundaries, falls back to a hard character cut."""
    chunks = []
    start = 0
    n = len(text)
    while start < n:
        end = min(start + chunk_size, n)
        window = text[start:end]

        if end < n:
            # prefer to break at the last paragraph or sentence boundary in the window
            break_at = max(window.rfind("\n\n"), window.rfind(". "))
            if break_at > chunk_size * 0.5:
                end = start + break_at + 1

        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)

        start = max(end - overlap, end) if end == n else end - overlap
        if end == n:
            break
    return chunks


def build_index():
    docs = load_documents()
    if not docs:
        raise SystemExit(f"No .txt/.md documents found in {DOCS_DIR}. Add some and rerun.")

    all_chunks, metadata = [], []
    for doc in docs:
        chunks = chunk_text(doc["text"])
        for i, chunk in enumerate(chunks):
            all_chunks.append(chunk)
            metadata.append({"source": doc["source"], "chunk_id": i})

    print(f"Loaded {len(docs)} documents -> {len(all_chunks)} chunks")

    embedder = Embedder()
    print("Generating embeddings...")
    vectors = embedder.embed(tqdm(all_chunks))

    store = VectorStore(dim=vectors.shape[1])
    store.add(vectors, all_chunks, metadata)
    store.save(INDEX_DIR)
    print(f"Saved FAISS index + metadata to {INDEX_DIR}/")


if __name__ == "__main__":
    build_index()
