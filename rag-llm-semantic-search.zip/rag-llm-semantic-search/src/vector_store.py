"""A thin FAISS-backed vector store with save/load and similarity search."""
import json
from pathlib import Path
from typing import List, Dict, Tuple
import numpy as np
import faiss


class VectorStore:
    def __init__(self, dim: int):
        self.dim = dim
        self.index = faiss.IndexFlatIP(dim)   # cosine similarity via normalized vectors
        self.chunks: List[str] = []
        self.metadata: List[Dict] = []

    def add(self, vectors: np.ndarray, chunks: List[str], metadata: List[Dict]):
        self.index.add(vectors.astype("float32"))
        self.chunks.extend(chunks)
        self.metadata.extend(metadata)

    def search(self, query_vector: np.ndarray, k: int = 4) -> List[Tuple[str, Dict, float]]:
        query_vector = query_vector.astype("float32").reshape(1, -1)
        scores, indices = self.index.search(query_vector, k)
        results = []
        for score, idx in zip(scores[0], indices[0]):
            if idx == -1:
                continue
            results.append((self.chunks[idx], self.metadata[idx], float(score)))
        return results

    def save(self, out_dir: Path):
        out_dir = Path(out_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        faiss.write_index(self.index, str(out_dir / "index.faiss"))
        with open(out_dir / "chunks.json", "w") as f:
            json.dump({"chunks": self.chunks, "metadata": self.metadata, "dim": self.dim}, f)

    @classmethod
    def load(cls, in_dir: Path) -> "VectorStore":
        in_dir = Path(in_dir)
        with open(in_dir / "chunks.json") as f:
            data = json.load(f)
        store = cls(dim=data["dim"])
        store.index = faiss.read_index(str(in_dir / "index.faiss"))
        store.chunks = data["chunks"]
        store.metadata = data["metadata"]
        return store
